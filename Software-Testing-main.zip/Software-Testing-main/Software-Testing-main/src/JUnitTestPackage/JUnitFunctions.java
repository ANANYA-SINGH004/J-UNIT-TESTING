package JUnitTestPackage;


public class JUnitFunctions {
public int addnumbers(int a,int b) {
	return a+b;
}

public String addstring(String x,String y) {
	return x+y;
}
}
